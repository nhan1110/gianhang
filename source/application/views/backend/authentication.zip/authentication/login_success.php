<?php
	echo "xin chao";

?>